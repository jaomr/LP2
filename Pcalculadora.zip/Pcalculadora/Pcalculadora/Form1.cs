namespace Pcalculadora
{
    public partial class Form1 : Form
    {
        double Numero1, Numero2;

        private void btnMais_Click(object sender, EventArgs e)
        {
            if
                 (double.TryParse(txtNumero1.Text, out Numero1) &&
                 double.TryParse(txtNumero2.Text, out Numero2))
            {
                double resultado;
                resultado = Numero1 + Numero2;
                txtResultado.Text = resultado.ToString("N2");
            }
            else
            {
                MessageBox.Show("Valores Inv�lidos", "Informe um valor v�lido!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtResultado.Focus();
            }
        }

        private void txtNumero1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            if
                 (double.TryParse(txtNumero1.Text, out Numero1) &&
                 double.TryParse(txtNumero2.Text, out Numero2))
            {
                double resultado;
                resultado = Numero1 - Numero2;
                txtResultado.Text = resultado.ToString("N2");
            }
            else
            {
                MessageBox.Show("Valores Inv�lidos", "Informe um valor v�lido!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtResultado.Focus();
            }
        }

        private void btnVezes_Click(object sender, EventArgs e)
        {
            if
                 (double.TryParse(txtNumero1.Text, out Numero1) &&
                 double.TryParse(txtNumero2.Text, out Numero2))
            {
                double resultado;
                resultado = Numero1 * Numero2;
                txtResultado.Text = resultado.ToString("N2");
            }
            else
            {
                MessageBox.Show("Valores Inv�lidos", "Informe um valor v�lido!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtResultado.Focus();
            }
        }

        private void btnDivi_Click(object sender, EventArgs e)
        {
            if
                (double.TryParse(txtNumero1.Text, out Numero1) &&
                double.TryParse(txtNumero2.Text, out Numero2))
            {


                if (Numero2 == 0)
                {   
                    MessageBox.Show("O dividendo tem que ser diferente de zero!", "Erro de valor!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txtNumero2.Focus();

                }
                
                else
                {
                    double resultado;
                    resultado = Numero1 / Numero2;
                    txtResultado.Text = resultado.ToString("N2");
                }
            }
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Text = "";
            txtResultado.Text = string.Empty;

            txtNumero1.Focus();
        }

        public Form1()
        {
            InitializeComponent();
            
        }

    } 
}
        