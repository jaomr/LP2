namespace PTriângulo
{
    public partial class Form1 : Form
    {
        double LadoA, LadoB, LadoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Text = "";
            txtLadoC.Text = string.Empty;

            txtLadoA.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
           if (!double.TryParse(txtLadoA.Text, out LadoA) ||
                !double.TryParse(txtLadoB.Text, out LadoB) ||
                !double.TryParse(txtLadoC.Text, out LadoC))
            {
                MessageBox.Show("valores devem ser númericos");
            }
           else
            {
                if (LadoA < (LadoB + LadoC) && LadoA>Math.Abs(LadoB - LadoC) && LadoB < (LadoA + LadoC) &&
                    LadoB>Math.Abs(LadoA - LadoC) && LadoC < (LadoA + LadoB) && LadoC>Math.Abs(LadoA - LadoB))
                {
                    if (LadoA == LadoB && LadoB == LadoC)
                    {
                        MessageBox.Show("O Triângulo é Equilátero");
                    }
                    else
                    {
                        if (LadoA == LadoB || LadoA == LadoC || LadoB == LadoC)
                        {
                            MessageBox.Show("O Triângulo é Isóceles");
                        }
                        else
                        {
                            MessageBox.Show("O triângulo é Escaleno");
                        }
                    }
                }
            }
        }
    }
}