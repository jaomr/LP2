﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PCameponato
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int[,] Gols = new int[3, 6];
            int [] Times = new int[6];
            int SaldoGols=0, Golsrecebidos=0, GolsFeitos=0, totalg=0, totalr=0;
            string TotalGolsFeitos, TotalGolsRecebidos;


            for (var i = 0; i <= 6; i++)
            {
                for (var j = 0; j < 2; j++)
                {

                    if (j == 0)
                    {
                        TotalGolsFeitos = Interaction.InputBox("Time : " + (i + 1) + " Gols feitos: ", "Entrada de dados");
                        if (!Int32.TryParse(TotalGolsFeitos, out GolsFeitos))
                        {
                            MessageBox.Show("Insira um dado valido!");
                            i--;
                        }
                        totalg = totalg + GolsFeitos;
                        
                    }


                    if (j == 1)
                    {
                        TotalGolsRecebidos = Interaction.InputBox("Time : " + (i + 1) + " Gols recebidos: ", "Entrada de dados");
                        if (!Int32.TryParse(TotalGolsRecebidos, out Golsrecebidos))
                        {
                            MessageBox.Show("Insira um dado valido!");
                            i--;
                        }

                        totalr = totalr + Golsrecebidos;
                        SaldoGols = GolsFeitos - Golsrecebidos;
                        ltbTimes.Items.Add("Time : " + (i + 1) + " Gols Feitos: " + GolsFeitos + " Gols recebidos: " + Golsrecebidos.ToString() + " Saldo de Gols: " + SaldoGols.ToString());
                    }
                }
              
            }
            ltbTimes.Items.Add("Total gols: " + totalg.ToString());
            ltbTimes.Items.Add("Total gols recebidos: " + totalr.ToString());
               

                    
               

            //TotalGolsFeitos = 
            
        }
    }
}
