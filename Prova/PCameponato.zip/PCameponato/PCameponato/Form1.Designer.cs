﻿namespace PCameponato
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExecutar = new System.Windows.Forms.Button();
            this.ltbTimes = new System.Windows.Forms.ListBox();
            this.lblteste = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnExecutar
            // 
            this.btnExecutar.Location = new System.Drawing.Point(52, 117);
            this.btnExecutar.Name = "btnExecutar";
            this.btnExecutar.Size = new System.Drawing.Size(89, 77);
            this.btnExecutar.TabIndex = 0;
            this.btnExecutar.Text = "Executar";
            this.btnExecutar.UseVisualStyleBackColor = true;
            this.btnExecutar.Click += new System.EventHandler(this.btnExecutar_Click);
            // 
            // ltbTimes
            // 
            this.ltbTimes.FormattingEnabled = true;
            this.ltbTimes.Location = new System.Drawing.Point(267, 26);
            this.ltbTimes.Name = "ltbTimes";
            this.ltbTimes.Size = new System.Drawing.Size(309, 290);
            this.ltbTimes.TabIndex = 1;
            // 
            // lblteste
            // 
            this.lblteste.AutoSize = true;
            this.lblteste.Location = new System.Drawing.Point(205, 149);
            this.lblteste.Name = "lblteste";
            this.lblteste.Size = new System.Drawing.Size(35, 13);
            this.lblteste.TabIndex = 2;
            this.lblteste.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(608, 350);
            this.Controls.Add(this.lblteste);
            this.Controls.Add(this.ltbTimes);
            this.Controls.Add(this.btnExecutar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExecutar;
        private System.Windows.Forms.ListBox ltbTimes;
        private System.Windows.Forms.Label lblteste;
    }
}

