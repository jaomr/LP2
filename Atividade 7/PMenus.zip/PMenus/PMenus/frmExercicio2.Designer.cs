﻿namespace PMenus
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.btnIguais = new System.Windows.Forms.Button();
            this.btnInserirTxt1Txt2 = new System.Windows.Forms.Button();
            this.btnInserirAstTxt1 = new System.Windows.Forms.Button();
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.lblPalavra2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Location = new System.Drawing.Point(260, 75);
            this.txtPalavra1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(179, 22);
            this.txtPalavra1.TabIndex = 0;
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Location = new System.Drawing.Point(260, 123);
            this.txtPalavra2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(179, 22);
            this.txtPalavra2.TabIndex = 1;
            // 
            // btnIguais
            // 
            this.btnIguais.Location = new System.Drawing.Point(160, 222);
            this.btnIguais.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnIguais.Name = "btnIguais";
            this.btnIguais.Size = new System.Drawing.Size(280, 28);
            this.btnIguais.TabIndex = 2;
            this.btnIguais.Text = "Testar Iguais";
            this.btnIguais.UseVisualStyleBackColor = true;
            this.btnIguais.Click += new System.EventHandler(this.btnIguais_Click);
            // 
            // btnInserirTxt1Txt2
            // 
            this.btnInserirTxt1Txt2.Location = new System.Drawing.Point(160, 261);
            this.btnInserirTxt1Txt2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnInserirTxt1Txt2.Name = "btnInserirTxt1Txt2";
            this.btnInserirTxt1Txt2.Size = new System.Drawing.Size(280, 28);
            this.btnInserirTxt1Txt2.TabIndex = 3;
            this.btnInserirTxt1Txt2.Text = "Inserir Texto 1 no Texto 2";
            this.btnInserirTxt1Txt2.UseVisualStyleBackColor = true;
            this.btnInserirTxt1Txt2.Click += new System.EventHandler(this.btnTxt1Txt2_Click);
            // 
            // btnInserirAstTxt1
            // 
            this.btnInserirAstTxt1.Location = new System.Drawing.Point(160, 297);
            this.btnInserirAstTxt1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnInserirAstTxt1.Name = "btnInserirAstTxt1";
            this.btnInserirAstTxt1.Size = new System.Drawing.Size(280, 28);
            this.btnInserirAstTxt1.TabIndex = 4;
            this.btnInserirAstTxt1.Text = "Inserir Asteriscos no Texto 1";
            this.btnInserirAstTxt1.UseVisualStyleBackColor = true;
            this.btnInserirAstTxt1.Click += new System.EventHandler(this.btnAstTxt1_Click);
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(156, 75);
            this.lblPalavra1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(64, 16);
            this.lblPalavra1.TabIndex = 5;
            this.lblPalavra1.Text = "Palavra 1";
            // 
            // lblPalavra2
            // 
            this.lblPalavra2.AutoSize = true;
            this.lblPalavra2.Location = new System.Drawing.Point(156, 123);
            this.lblPalavra2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPalavra2.Name = "lblPalavra2";
            this.lblPalavra2.Size = new System.Drawing.Size(64, 16);
            this.lblPalavra2.TabIndex = 6;
            this.lblPalavra2.Text = "Palavra 2";
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(579, 506);
            this.Controls.Add(this.lblPalavra2);
            this.Controls.Add(this.lblPalavra1);
            this.Controls.Add(this.btnInserirAstTxt1);
            this.Controls.Add(this.btnInserirTxt1Txt2);
            this.Controls.Add(this.btnIguais);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.txtPalavra1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmExercicio2";
            this.Text = "Exercício 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPalavra1;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.Button btnIguais;
        private System.Windows.Forms.Button btnInserirTxt1Txt2;
        private System.Windows.Forms.Button btnInserirAstTxt1;
        private System.Windows.Forms.Label lblPalavra1;
        private System.Windows.Forms.Label lblPalavra2;
    }
}