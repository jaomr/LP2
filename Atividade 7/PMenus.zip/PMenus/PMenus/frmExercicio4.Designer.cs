﻿namespace PMenus
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnQtdeCaracAlfa = new System.Windows.Forms.Button();
            this.btnPosiCaracBranco = new System.Windows.Forms.Button();
            this.btnQtdeCaracNum = new System.Windows.Forms.Button();
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnQtdeCaracAlfa
            // 
            this.btnQtdeCaracAlfa.Location = new System.Drawing.Point(160, 294);
            this.btnQtdeCaracAlfa.Margin = new System.Windows.Forms.Padding(4);
            this.btnQtdeCaracAlfa.Name = "btnQtdeCaracAlfa";
            this.btnQtdeCaracAlfa.Size = new System.Drawing.Size(280, 28);
            this.btnQtdeCaracAlfa.TabIndex = 7;
            this.btnQtdeCaracAlfa.Text = "Quantidade de Caracteres Alfabéticos";
            this.btnQtdeCaracAlfa.UseVisualStyleBackColor = true;
            this.btnQtdeCaracAlfa.Click += new System.EventHandler(this.btnCaracAlfa_Click);
            // 
            // btnPosiCaracBranco
            // 
            this.btnPosiCaracBranco.Location = new System.Drawing.Point(160, 258);
            this.btnPosiCaracBranco.Margin = new System.Windows.Forms.Padding(4);
            this.btnPosiCaracBranco.Name = "btnPosiCaracBranco";
            this.btnPosiCaracBranco.Size = new System.Drawing.Size(280, 28);
            this.btnPosiCaracBranco.TabIndex = 6;
            this.btnPosiCaracBranco.Text = "Posição primeiro Caracter Branco";
            this.btnPosiCaracBranco.UseVisualStyleBackColor = true;
            this.btnPosiCaracBranco.Click += new System.EventHandler(this.btnCaracBranco_Click);
            // 
            // btnQtdeCaracNum
            // 
            this.btnQtdeCaracNum.Location = new System.Drawing.Point(160, 222);
            this.btnQtdeCaracNum.Margin = new System.Windows.Forms.Padding(4);
            this.btnQtdeCaracNum.Name = "btnQtdeCaracNum";
            this.btnQtdeCaracNum.Size = new System.Drawing.Size(280, 28);
            this.btnQtdeCaracNum.TabIndex = 5;
            this.btnQtdeCaracNum.Text = "Quantidade de Caracteres Numéricos";
            this.btnQtdeCaracNum.UseVisualStyleBackColor = true;
            this.btnQtdeCaracNum.Click += new System.EventHandler(this.btnCaracNum_Click);
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(156, 75);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(279, 70);
            this.rchtxtFrase.TabIndex = 8;
            this.rchtxtFrase.Text = "";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(579, 506);
            this.Controls.Add(this.rchtxtFrase);
            this.Controls.Add(this.btnQtdeCaracAlfa);
            this.Controls.Add(this.btnPosiCaracBranco);
            this.Controls.Add(this.btnQtdeCaracNum);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmExercicio4";
            this.Text = "Exercício 4";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnQtdeCaracAlfa;
        private System.Windows.Forms.Button btnPosiCaracBranco;
        private System.Windows.Forms.Button btnQtdeCaracNum;
        private System.Windows.Forms.RichTextBox rchtxtFrase;
    }
}