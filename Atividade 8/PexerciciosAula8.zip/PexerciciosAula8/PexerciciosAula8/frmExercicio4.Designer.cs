﻿namespace PexerciciosAula8
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtSalBruto = new System.Windows.Forms.TextBox();
            this.txtGr = new System.Windows.Forms.TextBox();
            this.txtSal = new System.Windows.Forms.TextBox();
            this.txtPr = new System.Windows.Forms.TextBox();
            this.txtMat = new System.Windows.Forms.TextBox();
            this.txtCargo = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblSalarioBruto = new System.Windows.Forms.Label();
            this.lblGratificacao = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblProducao = new System.Windows.Forms.Label();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblCargo = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnLimpar.Location = new System.Drawing.Point(461, 252);
            this.btnLimpar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(150, 84);
            this.btnLimpar.TabIndex = 31;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnCalcular.Location = new System.Drawing.Point(461, 117);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(150, 84);
            this.btnCalcular.TabIndex = 30;
            this.btnCalcular.Text = "Calcular Salário Bruto";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtSalBruto
            // 
            this.txtSalBruto.Enabled = false;
            this.txtSalBruto.Location = new System.Drawing.Point(118, 340);
            this.txtSalBruto.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSalBruto.Name = "txtSalBruto";
            this.txtSalBruto.Size = new System.Drawing.Size(295, 27);
            this.txtSalBruto.TabIndex = 29;
            // 
            // txtGr
            // 
            this.txtGr.Location = new System.Drawing.Point(118, 248);
            this.txtGr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtGr.Name = "txtGr";
            this.txtGr.Size = new System.Drawing.Size(295, 27);
            this.txtGr.TabIndex = 28;
            // 
            // txtSal
            // 
            this.txtSal.Location = new System.Drawing.Point(118, 209);
            this.txtSal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSal.Name = "txtSal";
            this.txtSal.Size = new System.Drawing.Size(295, 27);
            this.txtSal.TabIndex = 27;
            // 
            // txtPr
            // 
            this.txtPr.Location = new System.Drawing.Point(118, 171);
            this.txtPr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPr.Name = "txtPr";
            this.txtPr.Size = new System.Drawing.Size(295, 27);
            this.txtPr.TabIndex = 26;
            // 
            // txtMat
            // 
            this.txtMat.Location = new System.Drawing.Point(118, 125);
            this.txtMat.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMat.Name = "txtMat";
            this.txtMat.Size = new System.Drawing.Size(295, 27);
            this.txtMat.TabIndex = 25;
            // 
            // txtCargo
            // 
            this.txtCargo.Location = new System.Drawing.Point(118, 80);
            this.txtCargo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCargo.Name = "txtCargo";
            this.txtCargo.Size = new System.Drawing.Size(295, 27);
            this.txtCargo.TabIndex = 24;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(118, 41);
            this.txtNome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(295, 27);
            this.txtNome.TabIndex = 23;
            // 
            // lblSalarioBruto
            // 
            this.lblSalarioBruto.AutoSize = true;
            this.lblSalarioBruto.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblSalarioBruto.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSalarioBruto.Location = new System.Drawing.Point(14, 341);
            this.lblSalarioBruto.Name = "lblSalarioBruto";
            this.lblSalarioBruto.Size = new System.Drawing.Size(115, 23);
            this.lblSalarioBruto.TabIndex = 22;
            this.lblSalarioBruto.Text = "Salário Bruto";
            // 
            // lblGratificacao
            // 
            this.lblGratificacao.AutoSize = true;
            this.lblGratificacao.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblGratificacao.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblGratificacao.Location = new System.Drawing.Point(25, 248);
            this.lblGratificacao.Name = "lblGratificacao";
            this.lblGratificacao.Size = new System.Drawing.Size(106, 23);
            this.lblGratificacao.TabIndex = 21;
            this.lblGratificacao.Text = "Gratificação";
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblSalario.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSalario.Location = new System.Drawing.Point(54, 209);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(65, 23);
            this.lblSalario.TabIndex = 20;
            this.lblSalario.Text = "Salário";
            // 
            // lblProducao
            // 
            this.lblProducao.AutoSize = true;
            this.lblProducao.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblProducao.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblProducao.Location = new System.Drawing.Point(42, 171);
            this.lblProducao.Name = "lblProducao";
            this.lblProducao.Size = new System.Drawing.Size(85, 23);
            this.lblProducao.TabIndex = 19;
            this.lblProducao.Text = "Produção";
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblMatricula.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblMatricula.Location = new System.Drawing.Point(42, 125);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(86, 23);
            this.lblMatricula.TabIndex = 18;
            this.lblMatricula.Text = "Matrícula";
            // 
            // lblCargo
            // 
            this.lblCargo.AutoSize = true;
            this.lblCargo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblCargo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCargo.Location = new System.Drawing.Point(61, 88);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(58, 23);
            this.lblCargo.TabIndex = 17;
            this.lblCargo.Text = "Cargo";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblNome.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblNome.Location = new System.Drawing.Point(63, 43);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(58, 23);
            this.lblNome.TabIndex = 16;
            this.lblNome.Text = "Nome";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PexerciciosAula8.Properties.Resources.Trab_Denilce_sanji;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(640, 443);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtSalBruto);
            this.Controls.Add(this.txtGr);
            this.Controls.Add(this.txtSal);
            this.Controls.Add(this.txtPr);
            this.Controls.Add(this.txtMat);
            this.Controls.Add(this.txtCargo);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblSalarioBruto);
            this.Controls.Add(this.lblGratificacao);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.lblProducao);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.lblCargo);
            this.Controls.Add(this.lblNome);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnLimpar;
        private Button btnCalcular;
        private TextBox txtSalBruto;
        private TextBox txtGr;
        private TextBox txtSal;
        private TextBox txtPr;
        private TextBox txtMat;
        private TextBox txtCargo;
        private TextBox txtNome;
        private Label lblSalarioBruto;
        private Label lblGratificacao;
        private Label lblSalario;
        private Label lblProducao;
        private Label lblMatricula;
        private Label lblCargo;
        private Label lblNome;
    }
}