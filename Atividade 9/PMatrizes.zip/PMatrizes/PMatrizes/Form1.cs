﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux;
            string saida = "";
            

            for(var i = 0; i < 20; i++)
            {
                aux = Interaction.InputBox("Digite o número", "Entrada de dados");
                if(!Int32.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Dado inválido");
                    i--;
                }
                else
                {
                    saida = vetor[i] + "\n" + saida;
                }
            }
            MessageBox.Show(saida);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double[] Qtd = new double[10];
            double[] Valor = new double[10];
            string aux = "";
            double Faturamento = 0;

            for(var i = 0; i < 10; i++)
            {
                aux = Interaction.InputBox("Digite a quantidadde de mercadoria" + (i + 1), "Entrada de quantidades");
                if (!Double.TryParse(aux, out Qtd[i]))
                {
                    MessageBox.Show("Quantidade inválida");
                    i--;
                }
                else
                {
                    while (Valor[i] <= 0)
                    {
                        aux = "";
                        aux = Interaction.InputBox("Digite o valor da mercadoria" + (i + 1), "Entrada de preços");
                        if(!Double.TryParse(aux, out Valor[i]))
                        {
                            MessageBox.Show("Preço inválido");

                        }
                    }
                }
                Faturamento += Qtd[i] * Valor[i];
            }
            MessageBox.Show(Faturamento.ToString("N2"));
        }

        private void btnMediaAluno_Click(object sender, EventArgs e)
        {
            double[,] Notas = new double[20, 3];
            string auxiliar;
            for(var i = 0; i < 20; i++)
            {
                for(var j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox("Digite a nota" + (j + 1) + "do aluno" + (i + 1), "Entrada de dados");
                    if(!Double.TryParse(auxiliar,out Notas[i,j]))
                    {
                        MessageBox.Show("Nota inválida");
                        j--;
                    }
                    else
                    {
                        if (!(Notas[i,j] >= 0 && Notas[i,j] <= 10))
                        {
                            MessageBox.Show("Nota inválida");
                            j--;
                        }
                    }
                }
                double media = (Notas[i, 0] + Notas[i, 1] + Notas[i, 2]) / 3;
                MessageBox.Show("Aluno" + (i+1) + "média" + media.ToString("N2"));
            }
        }

        private void btnVTotal_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
                MessageBox.Show(Total.ToString("N2"));
            }
        }

        private void btnArrayList_Click(object sender, EventArgs e)
        {
            List<string> Nomes = new List<string>()
            {"Igor", "André", "Gabriel", "Fátima", "João", "Janete", "Pedro", "Marcelo", "Pedro", "Thais"};

            Nomes.Remove("Pedro");

            for (int i = 0; i < Nomes.Count; i++)
            {
                MessageBox.Show(Nomes[i]);
            }
        }

        private void btnNomePessoa_Click(object sender, EventArgs e)
        {
            double valid = 0;
            string RaEsc;
            int Ra;

            RaEsc = Interaction.InputBox("Digite o seu RA ", "Entrada de dados");

            if (double.TryParse(RaEsc, out valid))
            {
                RaEsc = RaEsc.Substring(RaEsc.Length - 1, 1);
            }
            else
            {
                MessageBox.Show("RA inválido!");
            }
            int.TryParse(RaEsc, out Ra);

            if (Ra == 0)
            {
                Ra = 10;
            }
            string[] nomes = new string[Ra];
            string[] aux = new string[Ra];
            int[] compr = new int[Ra];

            for (var i = 0; i < Ra; i++)
            {
                nomes[i] = Interaction.InputBox("Digite o nome completo " + (i + 1), "Entrada de dados");
                if (double.TryParse(nomes[i], out valid))
                {
                    MessageBox.Show("Somente Letras!");
                    i--;
                }
                else
                {
                    aux[i] = nomes[i].Replace(" ", "");
                    compr[i] = aux[i].Length;
                    MessageBox.Show("O nome: " + nomes[i] + " tem " + compr[i] + " caracteres");
                }
            }
        }
    }
}
