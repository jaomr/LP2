﻿namespace PMatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLerNumEInverter = new System.Windows.Forms.Button();
            this.btnLerQtdEPrecMercadorias = new System.Windows.Forms.Button();
            this.btnVTotal = new System.Windows.Forms.Button();
            this.btnArrayList = new System.Windows.Forms.Button();
            this.btnMediaAluno = new System.Windows.Forms.Button();
            this.btnNomePessoa = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnLerNumEInverter
            // 
            this.btnLerNumEInverter.Location = new System.Drawing.Point(40, 7);
            this.btnLerNumEInverter.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLerNumEInverter.Name = "btnLerNumEInverter";
            this.btnLerNumEInverter.Size = new System.Drawing.Size(155, 53);
            this.btnLerNumEInverter.TabIndex = 0;
            this.btnLerNumEInverter.Text = "Ler 20 números e inverter";
            this.btnLerNumEInverter.UseVisualStyleBackColor = true;
            this.btnLerNumEInverter.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnLerQtdEPrecMercadorias
            // 
            this.btnLerQtdEPrecMercadorias.Location = new System.Drawing.Point(40, 68);
            this.btnLerQtdEPrecMercadorias.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLerQtdEPrecMercadorias.Name = "btnLerQtdEPrecMercadorias";
            this.btnLerQtdEPrecMercadorias.Size = new System.Drawing.Size(155, 52);
            this.btnLerQtdEPrecMercadorias.TabIndex = 1;
            this.btnLerQtdEPrecMercadorias.Text = "Ler Quant. e Preço Mercadorias";
            this.btnLerQtdEPrecMercadorias.UseVisualStyleBackColor = true;
            this.btnLerQtdEPrecMercadorias.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnVTotal
            // 
            this.btnVTotal.Location = new System.Drawing.Point(40, 127);
            this.btnVTotal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnVTotal.Name = "btnVTotal";
            this.btnVTotal.Size = new System.Drawing.Size(155, 52);
            this.btnVTotal.TabIndex = 2;
            this.btnVTotal.Text = "Variável Total";
            this.btnVTotal.UseVisualStyleBackColor = true;
            this.btnVTotal.Click += new System.EventHandler(this.btnVTotal_Click);
            // 
            // btnArrayList
            // 
            this.btnArrayList.Location = new System.Drawing.Point(231, 7);
            this.btnArrayList.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnArrayList.Name = "btnArrayList";
            this.btnArrayList.Size = new System.Drawing.Size(155, 52);
            this.btnArrayList.TabIndex = 3;
            this.btnArrayList.Text = "ArrayList";
            this.btnArrayList.UseVisualStyleBackColor = true;
            this.btnArrayList.Click += new System.EventHandler(this.btnArrayList_Click);
            // 
            // btnMediaAluno
            // 
            this.btnMediaAluno.Location = new System.Drawing.Point(231, 68);
            this.btnMediaAluno.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMediaAluno.Name = "btnMediaAluno";
            this.btnMediaAluno.Size = new System.Drawing.Size(155, 52);
            this.btnMediaAluno.TabIndex = 4;
            this.btnMediaAluno.Text = "Média Alunos";
            this.btnMediaAluno.UseVisualStyleBackColor = true;
            this.btnMediaAluno.Click += new System.EventHandler(this.btnMediaAluno_Click);
            // 
            // btnNomePessoa
            // 
            this.btnNomePessoa.Location = new System.Drawing.Point(231, 127);
            this.btnNomePessoa.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNomePessoa.Name = "btnNomePessoa";
            this.btnNomePessoa.Size = new System.Drawing.Size(155, 52);
            this.btnNomePessoa.TabIndex = 5;
            this.btnNomePessoa.Text = "Nomes Pessoas";
            this.btnNomePessoa.UseVisualStyleBackColor = true;
            this.btnNomePessoa.Click += new System.EventHandler(this.btnNomePessoa_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(421, 190);
            this.Controls.Add(this.btnNomePessoa);
            this.Controls.Add(this.btnMediaAluno);
            this.Controls.Add(this.btnArrayList);
            this.Controls.Add(this.btnVTotal);
            this.Controls.Add(this.btnLerQtdEPrecMercadorias);
            this.Controls.Add(this.btnLerNumEInverter);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLerNumEInverter;
        private System.Windows.Forms.Button btnLerQtdEPrecMercadorias;
        private System.Windows.Forms.Button btnVTotal;
        private System.Windows.Forms.Button btnArrayList;
        private System.Windows.Forms.Button btnMediaAluno;
        private System.Windows.Forms.Button btnNomePessoa;
    }
}

